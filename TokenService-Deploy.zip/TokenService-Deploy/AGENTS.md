# AGENTS.md

## Proyecto

Paquete de despliegue con **PSAppDeployToolkit v4 (PSADT)** que reemplaza el MSI de certificados en equipos Windows 10/11:
desinstala cualquier versión previa y luego instala la nueva, en modo silencioso, con log y códigos de salida estándar.

- Nombre del programa en `appwiz.cpl`: `GDE Firma Digital Service Firefox Catamarca`
  (versiones previas del parque pueden figurar como `GCBA Firma Digital`; por eso la
  detección es por regex `Firma Digital|tokensign|token.?service` y no por `UpgradeCode`,
  que en este MSI es el placeholder `{00000001-0001-0001-0001-000000000001}`)
- MSI actual: `token-service_v4.msi` — ProductCode `{B8A8BA6C-F8FA-4551-86C3-449375C60103}`, ProductVersion `2.0.0`, x86
- Destino de distribución: GPO / Intune / SCCM (500 equipos). Ver `README.md`.

## Estructura

```
Certificados/
├── Invoke-AppDeployToolkit.exe     # Lanzador. No modificar.
├── Invoke-AppDeployToolkit.ps1     # ÚNICO script de lógica a editar.
├── Files/                          # MSI a instalar.
├── SupportFiles/                   # Archivos auxiliares (.cer, transforms .mst).
├── Config/                         # config.psd1 del toolkit.
├── Assets/, Strings/               # UI y textos. No tocar salvo pedido.
├── PSAppDeployToolkit/             # Módulo. NUNCA modificar.
└── PSAppDeployToolkit.Extensions/  # Funciones propias, solo si hacen falta.
```

## Reglas

1. Toda la lógica va en `Invoke-AppDeployToolkit.ps1`, dentro de las fases existentes
   (Pre-Install, Install, Post-Install, Pre-Uninstall, Uninstall, Post-Uninstall, Repair).
2. Usar **solo funciones ADT** del módulo. No llamar `msiexec.exe` directo ni usar `Start-Process`.
   - Desinstalar versiones previas: `Uninstall-ADTApplication -FilterScript { $_.DisplayName -match '...' }`
   - Instalar MSI: `Start-ADTMsiProcess -Action Install -FilePath '<archivo>.msi'`
   - Consultar instalado: `Get-ADTApplication`
   - Logging: `Write-ADTLogEntry`
   - Rutas del paquete: `$adtSession.DirFiles`, `$adtSession.DirSupportFiles`
3. Prohibido `Win32_Product` / `Get-WmiObject Win32_Product` (dispara reparaciones MSI).
4. Compatible con **Windows PowerShell 5.1**. No usar sintaxis exclusiva de PowerShell 7.
5. Sin rutas absolutas a la máquina del desarrollador. Todo relativo al paquete.
6. Sin reinicios forzados. Si el MSI pide reinicio, devolver 3010 y dejarlo al despliegue.
7. Completar siempre `AppVendor`, `AppName`, `AppVersion`, `AppScriptDate` y `AppScriptAuthor` en `$adtSession`.
8. No agregar pasos, dependencias ni funciones que no se pidieron.

## Códigos de salida

| Código | Significado |
| --- | --- |
| 0 | OK |
| 3010 | OK, requiere reinicio |
| 1641 | OK, reinicio iniciado por el instalador |
| 60000–68999 | Reservados por PSADT |
| 69000–69999 | Códigos propios del proyecto |

## Comandos

Crear plantilla (una sola vez):

```powershell
Install-Module -Name PSAppDeployToolkit -Scope CurrentUser
Import-Module PSAppDeployToolkit
New-ADTTemplate -Destination 'C:\Paquetes' -Name 'Certificados'
```

Probar (consola como administrador, desde la carpeta del paquete):

```powershell
.\Invoke-AppDeployToolkit.exe -DeploymentType Install   -DeployMode Silent
.\Invoke-AppDeployToolkit.exe -DeploymentType Uninstall -DeployMode Silent
.\Invoke-AppDeployToolkit.exe -DeploymentType Install   -DeployMode Interactive
```

Logs: `C:\Windows\Logs\Software\`

## Criterios de aceptación

- [ ] Install en PC **con** versión previa: queda una sola entrada en `appwiz.cpl`, con la versión nueva.
- [ ] Install en PC **sin** versión previa: instala sin error.
- [ ] Uninstall: no queda entrada en `appwiz.cpl`.
- [ ] Ejecutar Install dos veces seguidas no falla.
- [ ] Código de salida 0 (o 3010) en todos los casos anteriores.
- [ ] Log sin errores de severidad 3.

## Al entregar cambios

Indicar: qué fase se modificó, qué se probó (de la lista anterior) y el código de salida obtenido.
